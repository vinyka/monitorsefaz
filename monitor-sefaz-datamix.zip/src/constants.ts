import { ServiceType } from './types';

export const SERVICE_TYPES: ServiceType[] = [ServiceType.NFe, ServiceType.NFCe, ServiceType.CTe];